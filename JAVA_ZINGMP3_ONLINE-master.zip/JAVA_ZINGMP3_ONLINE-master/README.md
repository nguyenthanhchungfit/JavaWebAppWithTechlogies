#Author:GiayNhap
<br>
 đã fix lỗi ( do zing mp3 thay đổi cấu trúc file ).
